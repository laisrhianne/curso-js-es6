console.log(!!(100 / 0));

// let num2 = Math.floor(num1);
// let num2 = Math.ceil(num1);
// let num2 = Math.round(num1);
// console.log(Math.max(1,2,3,4,5,-10,-50,1500,9,8,7,6));
// console.log(Math.min(1,2,3,4,5,-10,-50,1500,9,8,7,6));
// const aleatorio = Math.round(Math.random() * (10 - 5) + 5);
