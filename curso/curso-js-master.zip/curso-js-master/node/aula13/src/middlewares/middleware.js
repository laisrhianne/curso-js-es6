exports.middlewareGlobal = (req, res, next) => {
  next();
};

exports.outroMiddleware = (req, res, next) => {
  next();
};
