# Curso de Javascript do básico ao avançado

Este é o repositório de todos os exemplos que usei no curso de 
Javascript do básico ao avançado (https://www.udemy.com/course/curso-de-javascript-moderno-do-basico-ao-avancado/)

As aulas não estão na ordem de criação e não na ordem criada automaticamente
pela plataforma do curso.

Bons estudos.